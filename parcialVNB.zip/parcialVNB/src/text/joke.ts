export enum Attribute() {
    "animal"="animal",
    "career"="career",
    "celebrity"="celebrity",
    "dev"="dev",
    "explicit"="explicit",
    "fashion"="fashion",
    "food"="food",
    "history"="history",
    "money"="money",
    "movie"="movie",
    "music"="music",
    "political"="political",
    "religion"="religion",
    "science"="science",
    "sport"="sport",
    "travel"="travel",
}

export enum Attribute() {
"value" : "Chuck Norris: Chilling Hulking Undeniable Cunning Killing Not nice Order Ripped Righteous Invincible Sensational"
}